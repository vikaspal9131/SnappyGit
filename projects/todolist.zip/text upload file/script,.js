<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Todo List</title>
  <style>
    body { font-family: Arial, sans-serif; margin: 40px; }
    #todo-list { list-style: none; padding: 0; }
    #todo-list li { padding: 8px 0; border-bottom: 1px solid #eee; }
    .remove-btn { margin-left: 10px; color: red; cursor: pointer; }
  </style>
</head>
<body>
  <h1>Todo List</h1>
  <input type="text" id="todo-input" placeholder="Add a new task">
  <button onclick="addTodo()">Add</button>
  <ul id="todo-list"></ul>

  <script>
    function addTodo() {
      const input = document.getElementById('todo-input');
      const value = input.value.trim();
      if (value) {
        const li = document.createElement('li');
        li.textContent = value;
        const btn = document.createElement('span');
        btn.textContent = 'Remove';
        btn.className = 'remove-btn';
        btn.onclick = function() { li.remove(); };
        li.appendChild(btn);
        document.getElementById('todo-list').appendChild(li);
        input.value = '';
      }
    }
  </script>